/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veriyapilarifinalodevi_1;

/**
 *
 * @author İsmail ÖNER 02200201041
 */
public class PrintArray {

    public void print(int dizi[]) {

        for (int i = dizi.length - 1; i >= 0; i--) {
            System.out.print(dizi[i] + " ");
        }
    }
}
