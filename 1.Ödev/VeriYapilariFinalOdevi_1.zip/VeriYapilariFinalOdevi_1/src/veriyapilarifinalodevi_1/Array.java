/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package veriyapilarifinalodevi_1;

/**
 *
 * @author İsmail ÖNER 02200201041
 */
//Kullanıcının vereceği küçükten büyüğe sıralı dizi
public class Array {
    
    int array[];
    int es;
    
    public Array(int n,int array[]){
        es = n;
        this.array = array;
    }
    
}
